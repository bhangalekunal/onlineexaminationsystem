package com.saba.click.solr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataSolrApplicationTests {

	@Test
	void contextLoads() {
	}

}
